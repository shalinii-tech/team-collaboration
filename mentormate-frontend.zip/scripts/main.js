// Main JavaScript functionality
document.addEventListener("DOMContentLoaded", () => {
  // Mobile navigation toggle
  const hamburger = document.querySelector(".hamburger")
  const navMenu = document.querySelector(".nav-menu")

  if (hamburger && navMenu) {
    hamburger.addEventListener("click", () => {
      hamburger.classList.toggle("active")
      navMenu.classList.toggle("active")
    })
  }

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Add scroll effect to navbar
  const navbar = document.querySelector(".navbar")
  if (navbar) {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 50) {
        navbar.classList.add("scrolled")
      } else {
        navbar.classList.remove("scrolled")
      }
    })
  }

  // Intersection Observer for animations
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("animate-in")
      }
    })
  }, observerOptions)

  // Observe elements for animation
  document.querySelectorAll(".category-card, .step, .testimonial-card").forEach((el) => {
    observer.observe(el)
  })

  // Add loading states to buttons
  document.querySelectorAll('button[type="submit"]').forEach((button) => {
    button.addEventListener("click", function (e) {
      if (this.form && this.form.checkValidity()) {
        this.classList.add("loading")
        this.disabled = true

        // Simulate loading time
        setTimeout(() => {
          this.classList.remove("loading")
          this.disabled = false
        }, 2000)
      }
    })
  })

  // Notification system
  window.showNotification = (message, type = "info") => {
    const notification = document.createElement("div")
    notification.className = `notification notification-${type}`
    notification.textContent = message

    document.body.appendChild(notification)

    // Trigger animation
    setTimeout(() => notification.classList.add("show"), 100)

    // Remove after 5 seconds
    setTimeout(() => {
      notification.classList.remove("show")
      setTimeout(() => notification.remove(), 300)
    }, 5000)
  }

  // Form validation helpers
  window.validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(email)
  }

  window.validatePhone = (phone) => {
    const re = /^[+]?[1-9][\d]{0,15}$/
    return re.test(phone.replace(/\s/g, ""))
  }

  // Local storage helpers
  window.storage = {
    set: (key, value) => {
      try {
        localStorage.setItem(key, JSON.stringify(value))
      } catch (e) {
        console.error("Error saving to localStorage:", e)
      }
    },

    get: (key) => {
      try {
        const item = localStorage.getItem(key)
        return item ? JSON.parse(item) : null
      } catch (e) {
        console.error("Error reading from localStorage:", e)
        return null
      }
    },

    remove: (key) => {
      try {
        localStorage.removeItem(key)
      } catch (e) {
        console.error("Error removing from localStorage:", e)
      }
    },
  }

  // API helpers
  window.api = {
    baseUrl: "/api",

    request: async function (endpoint, options = {}) {
      const url = `${this.baseUrl}${endpoint}`
      const config = {
        headers: {
          "Content-Type": "application/json",
          ...options.headers,
        },
        ...options,
      }

      try {
        const response = await fetch(url, config)
        const data = await response.json()

        if (!response.ok) {
          throw new Error(data.message || "API request failed")
        }

        return data
      } catch (error) {
        console.error("API Error:", error)
        throw error
      }
    },

    get: function (endpoint) {
      return this.request(endpoint)
    },

    post: function (endpoint, data) {
      return this.request(endpoint, {
        method: "POST",
        body: JSON.stringify(data),
      })
    },

    put: function (endpoint, data) {
      return this.request(endpoint, {
        method: "PUT",
        body: JSON.stringify(data),
      })
    },

    delete: function (endpoint) {
      return this.request(endpoint, {
        method: "DELETE",
      })
    },
  }

  // Initialize tooltips
  document.querySelectorAll("[title]").forEach((element) => {
    element.addEventListener("mouseenter", function (e) {
      const tooltip = document.createElement("div")
      tooltip.className = "tooltip"
      tooltip.textContent = this.getAttribute("title")
      document.body.appendChild(tooltip)

      const rect = this.getBoundingClientRect()
      tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + "px"
      tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + "px"

      this.removeAttribute("title")
      this._originalTitle = tooltip.textContent
    })

    element.addEventListener("mouseleave", function () {
      const tooltip = document.querySelector(".tooltip")
      if (tooltip) {
        tooltip.remove()
      }
      if (this._originalTitle) {
        this.setAttribute("title", this._originalTitle)
      }
    })
  })
})

// Add CSS for animations and notifications
const style = document.createElement("style")
style.textContent = `
    .animate-in {
        animation: fadeInUp 0.6s ease-out forwards;
    }
    
    @keyframes fadeInUp {
        from {
            opacity: 0;
            transform: translateY(30px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 10000;
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 300px;
    }
    
    .notification.show {
        transform: translateX(0);
    }
    
    .notification-info {
        background: #2563eb;
    }
    
    .notification-success {
        background: #059669;
    }
    
    .notification-warning {
        background: #d97706;
    }
    
    .notification-error {
        background: #dc2626;
    }
    
    .tooltip {
        position: absolute;
        background: #1f2937;
        color: white;
        padding: 0.5rem 0.75rem;
        border-radius: 4px;
        font-size: 0.875rem;
        z-index: 10000;
        pointer-events: none;
    }
    
    .tooltip::after {
        content: '';
        position: absolute;
        top: 100%;
        left: 50%;
        transform: translateX(-50%);
        border: 5px solid transparent;
        border-top-color: #1f2937;
    }
    
    .loading {
        position: relative;
        color: transparent !important;
    }
    
    .loading::after {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 20px;
        height: 20px;
        border: 2px solid transparent;
        border-top: 2px solid currentColor;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        color: white;
    }
    
    @keyframes spin {
        to {
            transform: translate(-50%, -50%) rotate(360deg);
        }
    }
    
    .navbar.scrolled {
        background: rgba(255, 255, 255, 0.95);
        backdrop-filter: blur(10px);
    }
`
document.head.appendChild(style)
