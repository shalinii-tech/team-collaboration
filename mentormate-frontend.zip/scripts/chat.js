// Chat Interface JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Check authentication
  const user = window.storage.get("user")
  if (!user) {
    window.location.href = "login.html"
    return
  }

  // Chat functionality
  const messageInput = document.getElementById("messageInput")
  const sendBtn = document.getElementById("sendBtn")
  const chatMessages = document.getElementById("chatMessages")
  const chatSearch = document.getElementById("chatSearch")

  // Initialize chat
  initializeChat()

  function initializeChat() {
    // Load chat list
    const loadChatList = () => {
      // Implementation for loading chat list
      console.log("Loading chat list...")
    }

    // Set up event listeners
    const sendMessage = () => {
      // Implementation for sending message
      console.log("Sending message...")
    }

    const showTypingIndicator = () => {
      // Implementation for showing typing indicator
      console.log("Showing typing indicator...")
    }

    const debounce = (func, wait) => {
      // Implementation for debounce
      let timeout
      return function (...args) {
        
        clearTimeout(timeout)
        timeout = setTimeout(() => func.apply(this, args), wait)
      }
    }

    const searchChats = () => {
      // Implementation for searching chats
      console.log("Searching chats...")
    }

    const scrollToBottom = () => {
      // Implementation for scrolling to bottom
      console.log("Scrolling to bottom...")
    }

    loadChatList()

    if (sendBtn) {
      sendBtn.addEventListener("click", sendMessage)
    }

    if (messageInput) {
      messageInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault()
          sendMessage()
        }
      })

      messageInput.addEventListener("input", () => {
        // Show typing indicator to other user
        showTypingIndicator()
      })
    }

    if (chatSearch) {
      chatSearch.addEventListener("input", debounce(searchChats, 300))
    }

    // Auto-scroll to bottom
    scrollToBottom()
  }
})
