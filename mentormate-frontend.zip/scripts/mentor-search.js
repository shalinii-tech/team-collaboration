// Mentor Search JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Check authentication
  const user = window.storage.get("user")
  if (!user) {
    window.location.href = "login.html"
    return
  }

  // Search and filter functionality
  const searchInput = document.getElementById("searchInput")
  const categoryFilter = document.getElementById("categoryFilter")
  const experienceFilter = document.getElementById("experienceFilter")
  const priceFilter = document.getElementById("priceFilter")
  const ratingFilter = document.getElementById("ratingFilter")
  const availabilityFilter = document.getElementById("availabilityFilter")
  const sortBy = document.getElementById("sortBy")

  // Sample mentor data
  const mentors = [
    {
      id: "rajesh-kumar",
      name: "Dr. Rajesh Kumar",
      title: "Senior Software Architect",
      company: "Google India",
      rating: 4.9,
      reviews: 127,
      price: 999,
      experience: "15",
      category: "technology",
      tags: ["Career Development", "Technology"],
      bio: "15+ years in tech leadership. Helped 200+ engineers advance their careers at top companies.",
      sessions: 200,
      successRate: 95,
      status: "online",
      availability: "today",
    },
    {
      id: "sneha-patel",
      name: "Sneha Patel",
      title: "Life Coach & Therapist",
      company: "Certified Professional",
      rating: 4.8,
      reviews: 89,
      price: 699,
      experience: "8",
      category: "personal",
      tags: ["Personal Growth", "Relationships"],
      bio: "Certified life coach specializing in personal development and relationship counseling.",
      sessions: 150,
      successRate: 92,
      status: "online",
      availability: "today",
    },
    {
      id: "amit-sharma",
      name: "Amit Sharma",
      title: "Startup Founder & CEO",
      company: "TechVenture Solutions",
      rating: 4.7,
      reviews: 156,
      price: 1499,
      experience: "12",
      category: "entrepreneurship",
      tags: ["Entrepreneurship", "Business Strategy"],
      bio: "Serial entrepreneur with 3 successful exits. Expert in startup strategy and fundraising.",
      sessions: 300,
      successRate: 88,
      status: "busy",
      availability: "week",
    },
    {
      id: "priyanka-joshi",
      name: "Priyanka Joshi",
      title: "Product Manager",
      company: "Microsoft India",
      rating: 4.6,
      reviews: 73,
      price: 799,
      experience: "7",
      category: "career",
      tags: ["Product Management", "Career Transition"],
      bio: "Product leader with expertise in helping professionals transition into product roles.",
      sessions: 120,
      successRate: 94,
      status: "online",
      availability: "today",
    },
  ]

  let filteredMentors = [...mentors]

  // Event listeners
  searchInput.addEventListener("input", debounce(filterMentors, 300))
  categoryFilter.addEventListener("change", filterMentors)
  experienceFilter.addEventListener("change", filterMentors)
  priceFilter.addEventListener("change", filterMentors)
  ratingFilter.addEventListener("change", filterMentors)
  availabilityFilter.addEventListener("change", filterMentors)
  sortBy.addEventListener("change", sortMentors)

  function debounce(func, wait) {
    let timeout
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout)
        func(...args)
      }
      clearTimeout(timeout)
      timeout = setTimeout(later, wait)
    }
  }

  function filterMentors() {
    const searchTerm = searchInput.value.toLowerCase()
    const category = categoryFilter.value
    const experience = experienceFilter.value
    const price = priceFilter.value
    const rating = ratingFilter.value
    const availability = availabilityFilter.value

    filteredMentors = mentors.filter((mentor) => {
      // Search filter
      const matchesSearch =
        !searchTerm ||
        mentor.name.toLowerCase().includes(searchTerm) ||
        mentor.title.toLowerCase().includes(searchTerm) ||
        mentor.company.toLowerCase().includes(searchTerm) ||
        mentor.tags.some((tag) => tag.toLowerCase().includes(searchTerm))

      // Category filter
      const matchesCategory = !category || mentor.category === category

      // Experience filter
      const matchesExperience = !experience || checkExperienceRange(mentor.experience, experience)

      // Price filter
      const matchesPrice = !price || checkPriceRange(mentor.price, price)

      // Rating filter
      const matchesRating = !rating || mentor.rating >= Number.parseFloat(rating.replace("+", ""))

      // Availability filter
      const matchesAvailability = !availability || mentor.availability === availability

      return (
        matchesSearch && matchesCategory && matchesExperience && matchesPrice && matchesRating && matchesAvailability
      )
    })

    sortMentors()
  }

  function checkExperienceRange(experience, range) {
    const exp = Number.parseInt(experience)
    switch (range) {
      case "1-3":
        return exp >= 1 && exp <= 3
      case "3-5":
        return exp >= 3 && exp <= 5
      case "5-10":
        return exp >= 5 && exp <= 10
      case "10+":
        return exp >= 10
      default:
        return true
    }
  }

  function checkPriceRange(price, range) {
    switch (range) {
      case "0-500":
        return price >= 0 && price <= 500
      case "500-1000":
        return price >= 500 && price <= 1000
      case "1000-2000":
        return price >= 1000 && price <= 2000
      case "2000+":
        return price >= 2000
      default:
        return true
    }
  }

  function sortMentors() {
    const sortValue = sortBy.value

    switch (sortValue) {
      case "rating":
        filteredMentors.sort((a, b) => b.rating - a.rating)
        break
      case "price-low":
        filteredMentors.sort((a, b) => a.price - b.price)
        break
      case "price-high":
        filteredMentors.sort((a, b) => b.price - a.price)
        break
      case "experience":
        filteredMentors.sort((a, b) => Number.parseInt(b.experience) - Number.parseInt(a.experience))
        break
      default: // relevance
        // Keep original order for relevance
        break
    }

    renderMentors()
  }

  function renderMentors() {
    const mentorsGrid = document.querySelector(".mentors-grid")
    const resultsCount = document.querySelector(".results-count")

    if (resultsCount) {
      resultsCount.textContent = `(${filteredMentors.length} found)`
    }

    if (!mentorsGrid) return

    if (filteredMentors.length === 0) {
      mentorsGrid.innerHTML = `
                <div class="no-results">
                    <h3>No mentors found</h3>
                    <p>Try adjusting your search criteria or filters</p>
                </div>
            `
      return
    }

    mentorsGrid.innerHTML = filteredMentors
      .map(
        (mentor) => `
            <div class="mentor-card">
                <div class="mentor-header">
                    <div class="mentor-avatar"></div>
                    <div class="mentor-status ${mentor.status}"></div>
                </div>
                <div class="mentor-info">
                    <h3>${mentor.name}</h3>
                    <p class="mentor-title">${mentor.title}</p>
                    <p class="mentor-company">${mentor.company}</p>
                    <div class="mentor-rating">
                        <span class="stars">${"⭐".repeat(Math.floor(mentor.rating))}</span>
                        <span class="rating-text">${mentor.rating} (${mentor.reviews} reviews)</span>
                    </div>
                    <div class="mentor-tags">
                        ${mentor.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")}
                    </div>
                    <p class="mentor-bio">${mentor.bio}</p>
                    <div class="mentor-stats">
                        <div class="stat">
                            <span class="stat-number">${mentor.sessions}+</span>
                            <span class="stat-label">Sessions</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">${mentor.experience}</span>
                            <span class="stat-label">Years Exp</span>
                        </div>
                        <div class="stat">
                            <span class="stat-number">${mentor.successRate}%</span>
                            <span class="stat-label">Success Rate</span>
                        </div>
                    </div>
                </div>
                <div class="mentor-footer">
                    <div class="mentor-price">
                        <span class="price">₹${mentor.price}</span>
                        <span class="price-unit">/session</span>
                    </div>
                    <div class="mentor-actions">
                        <button class="btn-secondary" onclick="viewProfile('${mentor.id}')">View Profile</button>
                        <button class="btn-primary" onclick="bookSession('${mentor.id}')">Book Session</button>
                    </div>
                </div>
            </div>
        `,
      )
      .join("")
  }

  // Global functions for mentor actions
  window.viewProfile = (mentorId) => {
    window.location.href = `mentor-profile.html?id=${mentorId}`
  }

  window.bookSession = (mentorId) => {
    window.location.href = `booking.html?mentor=${mentorId}`
  }

  // Load more functionality
  const loadMoreBtn = document.querySelector(".load-more button")
  if (loadMoreBtn) {
    loadMoreBtn.addEventListener("click", () => {
      window.showNotification("Loading more mentors...", "info")
      // In a real app, this would load more mentors from the API
    })
  }

  // Initialize
  renderMentors()

  // Add styles for no results
  const style = document.createElement("style")
  style.textContent = `
        .no-results {
            grid-column: 1 / -1;
            text-align: center;
            padding: 3rem;
            color: #6b7280;
        }
        
        .no-results h3 {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
            color: #374151;
        }
        
        .no-results p {
            font-size: 1rem;
        }
    `
  document.head.appendChild(style)
})
