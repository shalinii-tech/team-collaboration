// Authentication JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // User type selector
  const userTypeButtons = document.querySelectorAll(".user-type-btn")
  const menteeOnlyFields = document.querySelectorAll(".mentee-only")

  userTypeButtons.forEach((button) => {
    button.addEventListener("click", function () {
      // Remove active class from all buttons
      userTypeButtons.forEach((btn) => btn.classList.remove("active"))
      // Add active class to clicked button
      this.classList.add("active")

      // Show/hide mentee-only fields
      const userType = this.dataset.type
      menteeOnlyFields.forEach((field) => {
        if (userType === "mentee") {
          field.style.display = "block"
        } else {
          field.style.display = "none"
        }
      })
    })
  })

  // Password toggle functionality
  window.togglePassword = () => {
    const passwordInputs = document.querySelectorAll('input[type="password"]')
    const toggleButtons = document.querySelectorAll(".password-toggle")

    passwordInputs.forEach((input, index) => {
      const toggle = toggleButtons[index]
      if (input.type === "password") {
        input.type = "text"
        toggle.textContent = "🙈"
      } else {
        input.type = "password"
        toggle.textContent = "👁️"
      }
    })
  }

  // Form validation
  const forms = document.querySelectorAll(".auth-form")

  forms.forEach((form) => {
    form.addEventListener("submit", function (e) {
      e.preventDefault()

      const formData = new FormData(this)
      const data = Object.fromEntries(formData.entries())

      // Validate form
      if (validateAuthForm(data, this)) {
        handleAuthSubmit(data, this)
      }
    })
  })

  function validateAuthForm(data, form) {
    let isValid = true
    const errors = []

    // Email validation
    if (data.email && !window.validateEmail(data.email)) {
      errors.push("Please enter a valid email address")
      isValid = false
    }

    // Phone validation (if present)
    if (data.phone && !window.validatePhone(data.phone)) {
      errors.push("Please enter a valid phone number")
      isValid = false
    }

    // Password validation for signup
    if (form.id === "signupForm") {
      if (data.password && data.password.length < 8) {
        errors.push("Password must be at least 8 characters long")
        isValid = false
      }

      if (data.password !== data.confirmPassword) {
        errors.push("Passwords do not match")
        isValid = false
      }

      if (!data.terms) {
        errors.push("Please accept the terms and conditions")
        isValid = false
      }
    }

    // Display errors
    if (!isValid) {
      showFormErrors(errors)
    }

    return isValid
  }

  function showFormErrors(errors) {
    // Remove existing error messages
    document.querySelectorAll(".form-error").forEach((error) => error.remove())

    // Create error container
    const errorContainer = document.createElement("div")
    errorContainer.className = "form-error"
    errorContainer.innerHTML = `
            <div style="background: #fee2e2; border: 1px solid #fecaca; color: #dc2626; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                <ul style="margin: 0; padding-left: 1.5rem;">
                    ${errors.map((error) => `<li>${error}</li>`).join("")}
                </ul>
            </div>
        `

    // Insert at the top of the form
    const form = document.querySelector(".auth-form")
    form.insertBefore(errorContainer, form.firstChild)
  }

  async function handleAuthSubmit(data, form) {
    const submitButton = form.querySelector('button[type="submit"]')
    const originalText = submitButton.textContent

    try {
      // Show loading state
      submitButton.textContent = "Please wait..."
      submitButton.disabled = true

      // Determine endpoint based on form
      let endpoint = "/auth/login"
      if (form.id === "signupForm") {
        endpoint = "/auth/signup"
      }

      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Store user data
      window.storage.set("user", {
        email: data.email,
        name: data.firstName ? `${data.firstName} ${data.lastName}` : "User",
        type: data.userType || "mentee",
      })

      // Show success message
      window.showNotification("Authentication successful! Redirecting...", "success")

      // Redirect to dashboard
      setTimeout(() => {
        window.location.href = "dashboard.html"
      }, 1500)
    } catch (error) {
      console.error("Auth error:", error)
      window.showNotification("Authentication failed. Please try again.", "error")
    } finally {
      // Reset button
      submitButton.textContent = originalText
      submitButton.disabled = false
    }
  }

  // Google authentication
  document.querySelectorAll(".btn-google").forEach((button) => {
    button.addEventListener("click", () => {
      // Simulate Google OAuth
      window.showNotification("Google authentication not implemented in demo", "info")
    })
  })

  // Auto-fill demo data
  if (window.location.search.includes("demo=true")) {
    setTimeout(() => {
      const emailInput = document.querySelector('input[name="email"]')
      const passwordInput = document.querySelector('input[name="password"]')

      if (emailInput && passwordInput) {
        emailInput.value = "demo@mentormate.com"
        passwordInput.value = "demo123456"

        if (document.querySelector('input[name="firstName"]')) {
          document.querySelector('input[name="firstName"]').value = "Demo"
          document.querySelector('input[name="lastName"]').value = "User"
          document.querySelector('input[name="phone"]').value = "+91 98765 43210"
          document.querySelector('select[name="city"]').value = "mumbai"
        }
      }
    }, 500)
  }

  // Check if user is already logged in
  const user = window.storage.get("user")
  if (user && (window.location.pathname.includes("login.html") || window.location.pathname.includes("signup.html"))) {
    window.location.href = "dashboard.html"
  }
})
