// Mentor Profile JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Check authentication
  const user = window.storage.get("user")
  if (!user) {
    window.location.href = "login.html"
    return
  }

  // Get mentor ID from URL
  const urlParams = new URLSearchParams(window.location.search)
  const mentorId = urlParams.get("id") || "rajesh-kumar"

  // Load mentor profile
  loadMentorProfile(mentorId)

  async function loadMentorProfile(id) {
    try {
      // Simulate API call
      const mentor = await getMentorData(id)
      renderMentorProfile(mentor)
    } catch (error) {
      console.error("Error loading mentor profile:", error)
      window.showNotification("Error loading mentor profile", "error")
    }
  }

  async function getMentorData(id) {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    // Sample mentor data
    const mentorData = {
      "rajesh-kumar": {
        id: "rajesh-kumar",
        name: "Dr. Rajesh Kumar",
        title: "Senior Software Architect at Google India",
        rating: 4.9,
        reviews: 127,
        price: 999,
        tags: ["Career Development", "Technology Leadership", "System Design", "Interview Prep"],
        stats: {
          sessions: 200,
          experience: 15,
          successRate: 95,
          responseTime: "24h",
        },
        about: `With over 15 years of experience in the technology industry, Dr. Rajesh Kumar has been instrumental in shaping the careers of hundreds of software engineers and tech professionals across India. Currently serving as a Senior Software Architect at Google India, he brings deep expertise in system design, technical leadership, and career advancement strategies.

Dr. Rajesh has worked with leading technology companies including Microsoft, Amazon, and Google, where he has led teams of 50+ engineers and delivered products used by millions of users. His mentorship approach focuses on practical, actionable advice that helps mentees navigate complex career decisions and technical challenges.

He holds a Ph.D. in Computer Science from IIT Delhi and has published over 20 research papers in top-tier conferences. Dr. Rajesh is passionate about giving back to the community and has mentored over 200 professionals, with 95% of his mentees achieving their career goals within 6 months.`,
        expertise: [
          {
            icon: "💼",
            title: "Career Development",
            description: "Strategic career planning, promotion strategies, and leadership development",
          },
          {
            icon: "🏗️",
            title: "System Design",
            description: "Large-scale system architecture, scalability, and performance optimization",
          },
          {
            icon: "👥",
            title: "Technical Leadership",
            description: "Team management, technical decision making, and engineering culture",
          },
          {
            icon: "🎯",
            title: "Interview Preparation",
            description: "Technical interviews, behavioral questions, and salary negotiation",
          },
        ],
        experience: [
          {
            period: "2020 - Present",
            title: "Senior Software Architect",
            company: "Google India",
            description:
              "Leading architecture for Google Pay India, serving 100M+ users. Responsible for system design, technical strategy, and team leadership.",
          },
          {
            period: "2017 - 2020",
            title: "Principal Engineer",
            company: "Amazon India",
            description:
              "Led the development of Amazon's logistics platform for India. Managed a team of 30+ engineers across multiple locations.",
          },
          {
            period: "2012 - 2017",
            title: "Senior Software Engineer",
            company: "Microsoft India",
            description:
              "Worked on Azure cloud services and Office 365. Contributed to multiple high-impact projects and mentored junior engineers.",
          },
        ],
        reviews: [
          {
            id: 1,
            author: "Ankit Verma",
            role: "Software Engineer at Flipkart",
            rating: 5,
            text: "Dr. Rajesh's guidance was instrumental in my promotion to Senior Engineer. His practical advice on system design and leadership helped me stand out in my team. Highly recommended!",
            date: "2 weeks ago",
          },
          {
            id: 2,
            author: "Kavya Reddy",
            role: "Product Manager at Zomato",
            rating: 5,
            text: "Transitioning from engineering to product management seemed impossible until I met Dr. Rajesh. His structured approach and industry insights made all the difference.",
            date: "1 month ago",
          },
          {
            id: 3,
            author: "Rohit Sharma",
            role: "Tech Lead at Paytm",
            rating: 5,
            text: "The interview preparation sessions were game-changing. Dr. Rajesh's mock interviews and feedback helped me crack Google's technical rounds with confidence.",
            date: "2 months ago",
          },
        ],
        availability: {
          responseTime: "Within 24 hours",
          sessionDuration: "60 minutes",
          timeZone: "IST (GMT +5:30)",
          languages: "English, Hindi",
        },
        timeSlots: [
          { date: "Tomorrow", time: "2:00 PM - 3:00 PM", available: true },
          { date: "Tomorrow", time: "6:00 PM - 7:00 PM", available: true },
          { date: "Friday", time: "10:00 AM - 11:00 AM", available: true },
          { date: "Friday", time: "4:00 PM - 5:00 PM", available: true },
        ],
      },
    }

    return mentorData[id] || mentorData["rajesh-kumar"]
  }

  function renderMentorProfile(mentor) {
    // Update page title
    document.title = `${mentor.name} - MentorMate`

    // Update profile header
    updateProfileHeader(mentor)

    // Update about section
    updateAboutSection(mentor)

    // Update expertise section
    updateExpertiseSection(mentor)

    // Update experience section
    updateExperienceSection(mentor)

    // Update reviews section
    updateReviewsSection(mentor)

    // Update availability section
    updateAvailabilitySection(mentor)
  }

  function updateProfileHeader(mentor) {
    const profileInfo = document.querySelector(".profile-info")
    if (!profileInfo) return

    profileInfo.querySelector("h1").textContent = mentor.name
    profileInfo.querySelector(".mentor-title").textContent = mentor.title

    const ratingText = profileInfo.querySelector(".rating-text")
    if (ratingText) {
      ratingText.textContent = `${mentor.rating} (${mentor.reviews} reviews)`
    }

    // Update tags
    const tagsContainer = profileInfo.querySelector(".mentor-tags")
    if (tagsContainer) {
      tagsContainer.innerHTML = mentor.tags.map((tag) => `<span class="tag">${tag}</span>`).join("")
    }

    // Update stats
    const stats = profileInfo.querySelectorAll(".stat")
    if (stats.length >= 4) {
      stats[0].querySelector(".stat-number").textContent = `${mentor.stats.sessions}+`
      stats[1].querySelector(".stat-number").textContent = mentor.stats.experience
      stats[2].querySelector(".stat-number").textContent = `${mentor.stats.successRate}%`
      stats[3].querySelector(".stat-number").textContent = mentor.stats.responseTime
    }

    // Update price
    const priceElement = document.querySelector(".price")
    if (priceElement) {
      priceElement.textContent = `₹${mentor.price}`
    }
  }

  function updateAboutSection(mentor) {
    const aboutContent = document.querySelector(".about-content")
    if (!aboutContent) return

    aboutContent.innerHTML = mentor.about
      .split("\n\n")
      .map((paragraph) => `<p>${paragraph}</p>`)
      .join("")
  }

  function updateExpertiseSection(mentor) {
    const expertiseGrid = document.querySelector(".expertise-grid")
    if (!expertiseGrid) return

    expertiseGrid.innerHTML = mentor.expertise
      .map(
        (item) => `
            <div class="expertise-item">
                <div class="expertise-icon">${item.icon}</div>
                <h3>${item.title}</h3>
                <p>${item.description}</p>
            </div>
        `,
      )
      .join("")
  }

  function updateExperienceSection(mentor) {
    const experienceTimeline = document.querySelector(".experience-timeline")
    if (!experienceTimeline) return

    experienceTimeline.innerHTML = mentor.experience
      .map(
        (exp) => `
            <div class="experience-item">
                <div class="experience-period">${exp.period}</div>
                <div class="experience-content">
                    <h3>${exp.title}</h3>
                    <p class="company">${exp.company}</p>
                    <p>${exp.description}</p>
                </div>
            </div>
        `,
      )
      .join("")
  }

  function updateReviewsSection(mentor) {
    const reviewsGrid = document.querySelector(".reviews-grid")
    if (!reviewsGrid) return

    reviewsGrid.innerHTML = mentor.reviews
      .map(
        (review) => `
            <div class="review-card">
                <div class="review-header">
                    <div class="reviewer-info">
                        <div class="reviewer-avatar"></div>
                        <div>
                            <h4>${review.author}</h4>
                            <p>${review.role}</p>
                        </div>
                    </div>
                    <div class="review-rating">${"⭐".repeat(review.rating)}</div>
                </div>
                <p>"${review.text}"</p>
                <span class="review-date">${review.date}</span>
            </div>
        `,
      )
      .join("")
  }

  function updateAvailabilitySection(mentor) {
    const availabilityInfo = document.querySelector(".availability-info")
    if (availabilityInfo) {
      const items = availabilityInfo.querySelectorAll(".availability-item")
      if (items.length >= 4) {
        items[0].querySelector(".availability-value").textContent = mentor.availability.responseTime
        items[1].querySelector(".availability-value").textContent = mentor.availability.sessionDuration
        items[2].querySelector(".availability-value").textContent = mentor.availability.timeZone
        items[3].querySelector(".availability-value").textContent = mentor.availability.languages
      }
    }

    const timeSlots = document.querySelector(".time-slots")
    if (timeSlots) {
      timeSlots.innerHTML = mentor.timeSlots
        .map(
          (slot) => `
                <div class="time-slot ${slot.available ? "available" : "booked"}">
                    <span class="slot-date">${slot.date}</span>
                    <span class="slot-time">${slot.time}</span>
                </div>
            `,
        )
        .join("")
    }
  }

  // Action handlers
  window.bookSession = () => {
    const urlParams = new URLSearchParams(window.location.search)
    const mentorId = urlParams.get("id") || "rajesh-kumar"
    window.location.href = `booking.html?mentor=${mentorId}`
  }

  window.sendMessage = () => {
    window.location.href = "chat.html"
  }

  window.addToFavorites = () => {
    const favorites = window.storage.get("favorites") || []
    const mentorId = new URLSearchParams(window.location.search).get("id") || "rajesh-kumar"

    if (!favorites.includes(mentorId)) {
      favorites.push(mentorId)
      window.storage.set("favorites", favorites)
      window.showNotification("Added to favorites!", "success")
    } else {
      window.showNotification("Already in favorites", "info")
    }
  }

  // View all reviews
  const viewAllReviewsBtn = document.querySelector(".profile-section button")
  if (viewAllReviewsBtn) {
    viewAllReviewsBtn.addEventListener("click", () => {
      window.showNotification("All reviews modal would open here", "info")
    })
  }

  // View full calendar
  const viewCalendarBtn = document.querySelector(".time-slots + .btn-primary")
  if (viewCalendarBtn) {
    viewCalendarBtn.addEventListener("click", () => {
      window.bookSession()
    })
  }
})
