// Dashboard JavaScript
document.addEventListener("DOMContentLoaded", () => {
  // Check authentication
  const user = window.storage.get("user")
  if (!user) {
    window.location.href = "login.html"
    return
  }

  // Update user name in navigation
  const userNameElement = document.querySelector(".user-name")
  if (userNameElement) {
    userNameElement.textContent = user.name
  }

  // Mobile sidebar toggle
  const sidebarToggle = document.querySelector(".sidebar-toggle")
  const sidebar = document.querySelector(".dashboard-sidebar")

  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener("click", () => {
      sidebar.classList.toggle("active")
    })
  }

  // Load dashboard data
  loadDashboardData()

  // Refresh data every 30 seconds
  setInterval(loadDashboardData, 30000)

  async function loadDashboardData() {
    try {
      // Simulate API calls
      const [stats, sessions, activities] = await Promise.all([
        loadUserStats(),
        loadUpcomingSessions(),
        loadRecentActivities(),
      ])

      updateStatsCards(stats)
      updateSessionsList(sessions)
      updateActivitiesList(activities)
    } catch (error) {
      console.error("Error loading dashboard data:", error)
      window.showNotification("Error loading dashboard data", "error")
    }
  }

  async function loadUserStats() {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    return {
      totalSessions: 12,
      averageRating: 4.8,
      goalsAchieved: 3,
      totalInvested: 8500,
    }
  }

  async function loadUpcomingSessions() {
    await new Promise((resolve) => setTimeout(resolve, 300))

    return [
      {
        id: 1,
        mentor: {
          name: "Dr. Rajesh Kumar",
          category: "Career Development",
          avatar: "avatar1.jpg",
        },
        date: "Tomorrow",
        time: "2:00 PM - 3:00 PM",
        status: "confirmed",
      },
      {
        id: 2,
        mentor: {
          name: "Sneha Patel",
          category: "Personal Growth",
          avatar: "avatar2.jpg",
        },
        date: "Friday",
        time: "6:00 PM - 7:00 PM",
        status: "confirmed",
      },
    ]
  }

  async function loadRecentActivities() {
    await new Promise((resolve) => setTimeout(resolve, 200))

    return [
      {
        id: 1,
        type: "session_completed",
        message: "Session completed with Dr. Rajesh Kumar",
        time: "2 hours ago",
        icon: "✅",
      },
      {
        id: 2,
        type: "message_received",
        message: "New message from Sneha Patel",
        time: "1 day ago",
        icon: "💬",
      },
      {
        id: 3,
        type: "rating_given",
        message: "Rated session with Amit Sharma - 5 stars",
        time: "3 days ago",
        icon: "⭐",
      },
    ]
  }

  function updateStatsCards(stats) {
    const statCards = document.querySelectorAll(".stat-card")

    if (statCards.length >= 4) {
      statCards[0].querySelector("h3").textContent = stats.totalSessions
      statCards[1].querySelector("h3").textContent = stats.averageRating
      statCards[2].querySelector("h3").textContent = stats.goalsAchieved
      statCards[3].querySelector("h3").textContent = `₹${stats.totalInvested.toLocaleString()}`
    }
  }

  function updateSessionsList(sessions) {
    const sessionsList = document.querySelector(".sessions-list")
    if (!sessionsList) return

    sessionsList.innerHTML = sessions
      .map(
        (session) => `
            <div class="session-card">
                <div class="session-mentor">
                    <div class="mentor-avatar"></div>
                    <div class="mentor-info">
                        <h4>${session.mentor.name}</h4>
                        <p>${session.mentor.category}</p>
                    </div>
                </div>
                <div class="session-details">
                    <div class="session-time">
                        <span class="date">${session.date}</span>
                        <span class="time">${session.time}</span>
                    </div>
                    <div class="session-actions">
                        <button class="btn-secondary" onclick="rescheduleSession(${session.id})">Reschedule</button>
                        <button class="btn-primary" onclick="joinSession(${session.id})">Join Call</button>
                    </div>
                </div>
            </div>
        `,
      )
      .join("")
  }

  function updateActivitiesList(activities) {
    const activitiesList = document.querySelector(".activity-list")
    if (!activitiesList) return

    activitiesList.innerHTML = activities
      .map(
        (activity) => `
            <div class="activity-item">
                <div class="activity-icon">${activity.icon}</div>
                <div class="activity-content">
                    <p><strong>${activity.message}</strong></p>
                    <span class="activity-time">${activity.time}</span>
                </div>
            </div>
        `,
      )
      .join("")
  }

  // Session actions
  window.rescheduleSession = (sessionId) => {
    window.showNotification("Reschedule functionality would open a calendar modal", "info")
  }

  window.joinSession = (sessionId) => {
    window.showNotification("Joining video call...", "success")
    // In a real app, this would open the video call interface
  }

  // User menu dropdown
  const userMenu = document.querySelector(".user-menu")
  if (userMenu) {
    userMenu.addEventListener("click", (e) => {
      e.stopPropagation()
      toggleUserDropdown()
    })
  }

  function toggleUserDropdown() {
    let dropdown = document.querySelector(".user-dropdown")

    if (!dropdown) {
      dropdown = document.createElement("div")
      dropdown.className = "user-dropdown"
      dropdown.innerHTML = `
                <div class="dropdown-menu">
                    <a href="#profile" class="dropdown-item">
                        <span class="dropdown-icon">👤</span>
                        <span>Profile</span>
                    </a>
                    <a href="#settings" class="dropdown-item">
                        <span class="dropdown-icon">⚙️</span>
                        <span>Settings</span>
                    </a>
                    <a href="#help" class="dropdown-item">
                        <span class="dropdown-icon">❓</span>
                        <span>Help</span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="#logout" class="dropdown-item" onclick="logout()">
                        <span class="dropdown-icon">🚪</span>
                        <span>Logout</span>
                    </a>
                </div>
            `

      userMenu.appendChild(dropdown)

      // Add styles
      const style = document.createElement("style")
      style.textContent = `
                .user-dropdown {
                    position: absolute;
                    top: 100%;
                    right: 0;
                    z-index: 1000;
                    margin-top: 0.5rem;
                }
                
                .dropdown-menu {
                    background: white;
                    border-radius: 8px;
                    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                    border: 1px solid #e5e7eb;
                    min-width: 200px;
                    padding: 0.5rem 0;
                }
                
                .dropdown-item {
                    display: flex;
                    align-items: center;
                    gap: 0.75rem;
                    padding: 0.75rem 1rem;
                    color: #374151;
                    text-decoration: none;
                    font-size: 0.875rem;
                    transition: background-color 0.2s;
                }
                
                .dropdown-item:hover {
                    background: #f3f4f6;
                }
                
                .dropdown-icon {
                    font-size: 1rem;
                }
                
                .dropdown-divider {
                    height: 1px;
                    background: #e5e7eb;
                    margin: 0.5rem 0;
                }
            `
      document.head.appendChild(style)
    }

    dropdown.style.display = dropdown.style.display === "none" ? "block" : "none"
  }

  // Close dropdown when clicking outside
  document.addEventListener("click", () => {
    const dropdown = document.querySelector(".user-dropdown")
    if (dropdown) {
      dropdown.style.display = "none"
    }
  })

  // Logout function
  window.logout = () => {
    window.storage.remove("user")
    window.showNotification("Logged out successfully", "success")
    setTimeout(() => {
      window.location.href = "index.html"
    }, 1000)
  }

  // Notification handling
  const notificationIcon = document.querySelector(".notification-icon")
  if (notificationIcon) {
    notificationIcon.addEventListener("click", () => {
      window.showNotification("Notifications panel would open here", "info")
    })
  }
})
